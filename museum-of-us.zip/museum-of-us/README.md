# The Museum of Us — Hybrid prototype
Open `index.html` in a browser. For best results, serve the folder with a local static server.

## Customize
- `data.js`: archive entries/content.
- Replace PHOTO placeholders in `index.html` with `<img>` tags.
- Add your audio/video under an `assets/` folder and wire them into `app.js`.
- Change the recipient-facing copy directly in `index.html`.

This first build establishes the visual system, museum floors, US.exe game, collectible fragments, archive, restricted room, and ending. A production version can replace the CSS pseudo-3D presentation with Three.js/WebGL rooms/models while keeping the content architecture.
