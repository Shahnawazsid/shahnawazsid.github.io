const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];let secrets=new Set();
$('#enter').onclick=()=>{$('#boot').classList.add('hidden');$('#app').classList.remove('hidden');window.scrollTo(0,0)};
$('#mapBtn').onclick=()=>$('#directory').classList.remove('hidden');$$('.close').forEach(x=>x.onclick=()=>x.parentElement.classList.add('hidden'));
$$('[data-go]').forEach(a=>a.onclick=e=>{e.preventDefault();$('#directory').classList.add('hidden');const r=$$('[data-room]').find(x=>x.dataset.room===a.dataset.go);r.scrollIntoView({behavior:'smooth'})});
$$('[data-modal]').forEach(x=>x.onclick=()=>$('#modal').classList.remove('hidden'));
$$('.secret').forEach(x=>x.onclick=()=>{secrets.add(x.dataset.secret);update();x.textContent='FRAGMENT FOUND ✓'});
function update(){ $('#secretCount').textContent=secrets.size }
const grid=$('#archiveGrid');MUSEUM_DATA.archive.forEach((x,i)=>{let d=document.createElement('article');d.className='archive-card';d.innerHTML=`<b>${String(i+1).padStart(3,'0')} / ${x.type}</b><h3>${x.title}</h3><p>${x.text}</p>`;d.onclick=()=>{if(i<5){secrets.add(String(i+1));update();d.style.outline='1px solid #b98794'}};grid.appendChild(d)});
let playing=false;$('#playDemo').onclick=()=>{playing=!playing;$('#vinyl').classList.toggle('playing',playing);$('#playDemo').textContent=playing?'PAUSE':'PLAY AMBIENCE'};
$$('.answer').forEach((b,i)=>b.onclick=()=>{secrets.add('game');update();$('#game').innerHTML=`<h3>${i?'CORRECT. PROBABLY.':'BOLD ANSWER.'}</h3><p>Fragment recovered.</p>`});
$('#unlock').onclick=()=>{if(secrets.size>=5){$('#door').innerHTML='<div><p class="mono">ACCESS GRANTED</p><h2>FOR HER EYES ONLY.</h2><p>This is where your final letter, long voice note or private film goes.</p></div>'}else alert(`ACCESS DENIED — ${5-secrets.size} fragments still missing.`)};
const observer=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)$('#roomLabel').textContent=e.target.dataset.room}),{threshold:.45});$$('.room').forEach(r=>observer.observe(r));
