window.MUSEUM_DATA={archive:[
{type:'PHOTO',title:'The first one',text:'Replace this with the story behind an important photograph.'},
{type:'VOICE',title:'03:17 AM',text:'A voice memo she can discover instead of receiving all at once.'},
{type:'SCREENSHOT',title:'Out of context',text:'Put one of your funniest old conversations here.'},
{type:'SONG',title:'Track 07',text:'Why this song belongs to the two of you.'},
{type:'VIDEO',title:'A random Tuesday',text:'The ordinary memories usually age the best.'},
{type:'CLASSIFIED',title:'???',text:'Locked until she finds enough fragments.'}
]};
